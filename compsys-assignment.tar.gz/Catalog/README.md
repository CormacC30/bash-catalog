Author: Cormac Costello
Description: This is a simple bash program for adding, searching, removing and deleting records from a music catalog

First execute `./welcome.sh` to start the program, and view the main menu

Records are written to and read from "musictracks.csv"

VIDEO DEMO: https://youtu.be/j1LPZSMR32w

Thanks, and hope you enjoy! 